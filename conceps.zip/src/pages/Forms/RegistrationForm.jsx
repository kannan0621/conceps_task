import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import styles from './RegistrationForm.module.css';

const RegistrationForm = () => {
    const navigate = useNavigate();
    const [formData, setFormData] = useState({
        fullName: '',
        email: '',
        contactNumber: '',
        department: '',
        state: '',
        city: '',
        address: '',
        currentlyWorking: false,
        experience: []
    });

    const [errors, setErrors] = useState({});

    const validateField = (name, value) => {
        let error = "";
        switch (name) {
            case 'fullName':
                if (!value.trim()) error = "Full name is required.";
                else if (!/^[a-zA-Z\s]{3,}$/.test(value)) error = "Name must be at least 3 characters and contain only letters.";
                break;
            case 'email':
                if (!value.trim()) error = "Email is required.";
                else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) error = "Please enter a valid email address.";
                break;
            case 'contactNumber':
                if (!value.trim()) error = "Contact number is required.";
                else if (!/^\d{10}$/.test(value)) error = "Contact number must be exactly 10 digits.";
                break;
            case 'department':
                if (!value) error = "Please select a department.";
                break;
            case 'state':
                if (!value) error = "Please select a state.";
                break;
            case 'city':
                if (!value) error = "Please select a city.";
                break;
            case 'address':
                if (!value.trim()) error = "Address is required.";
                break;
            default:
                break;
        }
        return error;
    };

    const handleChange = (e) => {
        const { name, value, type, checked } = e.target;
        const newValue = type === 'checkbox' ? checked : value;

        setFormData(prev => ({
            ...prev,
            [name]: newValue
        }));

        // Real-time validation
        const error = validateField(name, newValue);
        setErrors(prev => ({
            ...prev,
            [name]: error
        }));
    };

    const handleExperienceChange = (value) => {
        setFormData(prev => {
            const newExperience = prev.experience.includes(value)
                ? prev.experience.filter(item => item !== value)
                : [...prev.experience, value];
            return { ...prev, experience: newExperience };
        });
    };

    const validateForm = () => {
        let tempErrors = {};
        Object.keys(formData).forEach(key => {
            if (key !== 'currentlyWorking' && key !== 'experience') {
                const error = validateField(key, formData[key]);
                if (error) tempErrors[key] = error;
            }
        });
        setErrors(tempErrors);
        return Object.keys(tempErrors).length === 0;
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        if (validateForm()) {
            console.log('Form Submitted:', formData);
            navigate('/lists/users');
        } else {
            console.log('Validation Failed');
        }
    };

    return (
        <div className={styles.container}>
            <form className={styles.card} onSubmit={handleSubmit} noValidate>
                <div className={styles.header}>
                    <h2 className={styles.title}>Registration Form</h2>
                    <p className={styles.subtitle}>Please enter your personal and professional details.</p>
                </div>

                <div className={styles.formBody}>
                    {/* Personal Info */}
                    <div className={styles.section}>
                        <h3 className={styles.sectionTitle}>Personal Information</h3>

                        <div className={styles.row}>
                            <div className={styles.col}>
                                <label className={styles.label}>Full Name</label>
                                <input
                                    type="text"
                                    name="fullName"
                                    value={formData.fullName}
                                    onChange={handleChange}
                                    className={styles.input}
                                />
                                {errors.fullName && <span style={{ color: 'red', fontSize: '12px' }}>{errors.fullName}</span>}
                            </div>
                            <div className={styles.col}>
                                <label className={styles.label}>Email Address</label>
                                <input
                                    type="email"
                                    name="email"
                                    value={formData.email}
                                    onChange={handleChange}
                                    className={styles.input}
                                />
                                {errors.email && <span style={{ color: 'red', fontSize: '12px' }}>{errors.email}</span>}
                            </div>
                        </div>

                        <div className={styles.row}>
                            <div className={styles.col}>
                                <label className={styles.label}>Contact Number</label>
                                <input
                                    type="tel"
                                    name="contactNumber"
                                    value={formData.contactNumber}
                                    onChange={handleChange}
                                    className={styles.input}
                                />
                                {errors.contactNumber && <span style={{ color: 'red', fontSize: '12px' }}>{errors.contactNumber}</span>}
                            </div>
                            <div className={styles.col}>
                                <label className={styles.label}>Address</label>
                                <input
                                    type="text"
                                    name="address"
                                    value={formData.address}
                                    onChange={handleChange}
                                    className={styles.input}
                                    placeholder="Street Address"
                                />
                                {errors.address && <span style={{ color: 'red', fontSize: '12px' }}>{errors.address}</span>}
                            </div>
                        </div>
                    </div>

                    {/* Location & Department */}
                    <div className={styles.section}>
                        <h3 className={styles.sectionTitle}>Professional Details</h3>

                        <div className={styles.row}>
                            <div className={styles.col}>
                                <label className={styles.label}>Department</label>
                                <select
                                    name="department"
                                    value={formData.department}
                                    onChange={handleChange}
                                    className={styles.select}
                                >
                                    <option value="">Select Department</option>
                                    <option value="IT">IT</option>
                                    <option value="HR">HR</option>
                                    <option value="Sales">Sales</option>
                                    <option value="Marketing">Marketing</option>
                                </select>
                                {errors.department && <span style={{ color: 'red', fontSize: '12px' }}>{errors.department}</span>}
                            </div>
                        </div>

                        <div className={styles.row}>
                            <div className={styles.col}>
                                <label className={styles.label}>State</label>
                                <select
                                    name="state"
                                    value={formData.state}
                                    onChange={handleChange}
                                    className={styles.select}
                                >
                                    <option value="">Select State</option>
                                    <option value="Tamil Nadu">Tamil Nadu</option>
                                    <option value="Kerala">Kerala</option>
                                    <option value="Karnataka">Karnataka</option>
                                </select>
                                {errors.state && <span style={{ color: 'red', fontSize: '12px' }}>{errors.state}</span>}
                            </div>
                            <div className={styles.col}>
                                <label className={styles.label}>City</label>
                                <select
                                    name="city"
                                    value={formData.city}
                                    onChange={handleChange}
                                    className={styles.select}
                                >
                                    <option value="">Select City</option>
                                    <option value="Chennai">Chennai</option>
                                    <option value="Coimbatore">Coimbatore</option>
                                    <option value="Bangalore">Bangalore</option>
                                    <option value="Kochi">Kochi</option>
                                </select>
                                {errors.city && <span style={{ color: 'red', fontSize: '12px' }}>{errors.city}</span>}
                            </div>
                        </div>

                        <div className={styles.row}>
                            <div className={styles.col}>
                                <label className={styles.label}>Currently Working?</label>
                                <div className={styles.checkboxGroup}>
                                    <label className={styles.checkboxLabel}>
                                        <input
                                            type="checkbox"
                                            name="currentlyWorking"
                                            checked={formData.currentlyWorking}
                                            onChange={handleChange}
                                        /> Yes
                                    </label>
                                </div>
                            </div>
                        </div>

                        <div className={styles.row}>
                            <div className={styles.col}>
                                <label className={styles.label}>Years of Experience</label>
                                <div className={styles.checkboxGroup} style={{ flexDirection: 'row', gap: '20px' }}>
                                    <label className={styles.checkboxLabel}>
                                        <input
                                            type="checkbox"
                                            checked={formData.experience.includes('1year')}
                                            onChange={() => handleExperienceChange('1year')}
                                        /> 1 year
                                    </label>
                                    <label className={styles.checkboxLabel}>
                                        <input
                                            type="checkbox"
                                            checked={formData.experience.includes('2+years')}
                                            onChange={() => handleExperienceChange('2+years')}
                                        /> 2+ years
                                    </label>
                                    <label className={styles.checkboxLabel}>
                                        <input
                                            type="checkbox"
                                            checked={formData.experience.includes('4+years')}
                                            onChange={() => handleExperienceChange('4+years')}
                                        /> 4+ years
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div className={styles.actions}>
                    <button type="submit" className="btn btn-primary">Register</button>
                </div>
            </form>
        </div>
    );
};

export default RegistrationForm;
