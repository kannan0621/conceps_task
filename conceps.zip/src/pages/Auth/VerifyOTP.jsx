import React, { useState, useRef, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { MdSmartphone } from 'react-icons/md';
import styles from '../../styles/Auth.module.css';

const VerifyOTP = () => {
    const navigate = useNavigate();
    const [otp, setOtp] = useState(new Array(6).fill(""));
    const inputRefs = useRef([]);

    useEffect(() => {
        if (inputRefs.current[0]) {
            inputRefs.current[0].focus();
        }
    }, []);

    const handleChange = (element, index) => {
        if (isNaN(element.value)) return false;

        setOtp([...otp.map((d, idx) => (idx === index ? element.value : d))]);

        // Focus next input
        if (element.value !== "" && index < 5) {
            inputRefs.current[index + 1].focus();
        }
    };

    const handleKeyDown = (e, index) => {
        if (e.key === "Backspace") {
            if (otp[index] === "" && index > 0) {
                inputRefs.current[index - 1].focus();
            }
        }
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        console.log("OTP Entered:", otp.join(""));
        navigate('/');
    };

    return (
        <div className={styles.container}>
            <div className={styles.card} style={{ textAlign: 'center' }}>
                <div style={{ color: '#94a3b8', marginBottom: '20px' }}>
                    <MdSmartphone size={64} />
                </div>

                <h2 className={styles.title}>Verify your phone</h2>
                <p className={styles.subtitle}>
                    Enter the verification code we sent to <br />
                    <strong>******1234</strong>
                </p>

                <form className={styles.form} onSubmit={handleSubmit}>
                    <div className={styles.otpContainer}>
                        {otp.map((data, index) => (
                            <input
                                key={index}
                                type="text"
                                maxLength="1"
                                className={styles.otpInput}
                                value={data}
                                ref={el => inputRefs.current[index] = el}
                                onChange={e => handleChange(e.target, index)}
                                onKeyDown={e => handleKeyDown(e, index)}
                                onFocus={e => e.target.select()}
                            />
                        ))}
                    </div>

                    <div className={styles.resend}>
                        Didn't receive a code? (37s) <a href="#">Resend</a>
                    </div>

                    <button type="submit" className={styles.submitBtn}>
                        Continue
                    </button>
                </form>
            </div>
        </div>
    );
};

export default VerifyOTP;
