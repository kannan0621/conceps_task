import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { FcGoogle } from 'react-icons/fc';
import { FaApple } from 'react-icons/fa';
import { MdVisibility, MdVisibilityOff } from 'react-icons/md';
import styles from '../../styles/Auth.module.css';

const SignUp = () => {
    const [showPassword, setShowPassword] = useState(false);
    const navigate = useNavigate();

    const handleSubmit = (e) => {
        e.preventDefault();
        navigate('/auth/verify-otp');
    };

    return (
        <div className={styles.container}>
            <div className={styles.card}>
                <h2 className={styles.title}>Sign up</h2>
                <p className={styles.subtitle}>
                    Already have an Account? <Link to="/auth/signin">Sign in</Link>
                </p>

                <div className={styles.socialButtons}>
                    <button className={styles.socialBtn}>
                        <FcGoogle size={20} /> Use Google
                    </button>
                    <button className={styles.socialBtn}>
                        <FaApple size={20} /> Use Apple
                    </button>
                </div>

                <div className={styles.divider}>OR</div>

                <form className={styles.form} onSubmit={handleSubmit}>
                    <div className={styles.inputGroup}>
                        <label>Email</label>
                        <input
                            type="email"
                            placeholder="email@email.com"
                            className={styles.input}
                            required
                        />
                    </div>

                    <div className={styles.inputGroup}>
                        <label>Password</label>
                        <div className={styles.inputWrapper}>
                            <input
                                type={showPassword ? "text" : "password"}
                                placeholder="Enter Password"
                                className={styles.input}
                                required
                            />
                            <span
                                className={styles.eyeIcon}
                                onClick={() => setShowPassword(!showPassword)}
                            >
                                {showPassword ? <MdVisibilityOff /> : <MdVisibility />}
                            </span>
                        </div>
                    </div>

                    <div className={styles.inputGroup}>
                        <label>Confirm Password</label>
                        <div className={styles.inputWrapper}>
                            <input
                                type={showPassword ? "text" : "password"}
                                placeholder="Re-enter Password"
                                className={styles.input}
                                required
                            />
                            <span
                                className={styles.eyeIcon}
                                onClick={() => setShowPassword(!showPassword)}
                            >
                                {showPassword ? <MdVisibilityOff /> : <MdVisibility />}
                            </span>
                        </div>
                    </div>

                    <label className={styles.checkbox} style={{ fontSize: '0.875rem' }}>
                        <input type="checkbox" required /> I accept <Link to="#" className={styles.forgotPass} style={{ marginLeft: '4px' }}>Terms & Conditions</Link>
                    </label>

                    <button type="submit" className={styles.submitBtn}>
                        Sign Up
                    </button>
                </form>
            </div>
        </div>
    );
};

export default SignUp;
