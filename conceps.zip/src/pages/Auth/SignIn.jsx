import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { FcGoogle } from 'react-icons/fc';
import { FaApple } from 'react-icons/fa';
import { MdVisibility, MdVisibilityOff } from 'react-icons/md';
import styles from '../../styles/Auth.module.css';

const SignIn = () => {
    const [showPassword, setShowPassword] = useState(false);
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState('');
    const navigate = useNavigate();

    const handleSubmit = (e) => {
        e.preventDefault();
        if (email === 'admin@gmail.com' && password === 'Admin@123') {
            navigate('/auth/verify-otp');
        } else {
            setError('Invalid email or password');
        }
    };

    return (
        <div className={styles.container}>
            <div className={styles.card}>
                <h2 className={styles.title}>Sign in</h2>
                <p className={styles.subtitle}>
                    Need an account? <Link to="/auth/signup">Sign up</Link>
                </p>

                <div className={styles.socialButtons}>
                    <button className={styles.socialBtn}>
                        <FcGoogle size={20} /> Use Google
                    </button>
                    <button className={styles.socialBtn}>
                        <FaApple size={20} /> Use Apple
                    </button>
                </div>

                <div className={styles.divider}>OR</div>

                {error && <div style={{ color: 'red', textAlign: 'center', marginBottom: '1rem' }}>{error}</div>}

                <form className={styles.form} onSubmit={handleSubmit}>
                    <div className={styles.inputGroup}>
                        <label>Email</label>
                        <input
                            type="email"
                            placeholder="email@email.com"
                            className={styles.input}
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                            required
                        />
                    </div>

                    <div className={styles.inputGroup}>
                        <label>Password</label>
                        <div className={styles.inputWrapper}>
                            <input
                                type={showPassword ? "text" : "password"}
                                placeholder="Enter Password"
                                className={styles.input}
                                value={password}
                                onChange={(e) => setPassword(e.target.value)}
                                required
                            />
                            <span
                                className={styles.eyeIcon}
                                onClick={() => setShowPassword(!showPassword)}
                            >
                                {showPassword ? <MdVisibilityOff /> : <MdVisibility />}
                            </span>
                        </div>
                    </div>

                    <div className={styles.actions}>
                        <label className={styles.checkbox}>
                            <input type="checkbox" /> Remember me
                        </label>
                        <Link to="#" className={styles.forgotPass}>Forgot Password?</Link>
                    </div>

                    <button type="submit" className={styles.submitBtn}>
                        Sign In
                    </button>
                </form>
            </div>
        </div>
    );
};

export default SignIn;
