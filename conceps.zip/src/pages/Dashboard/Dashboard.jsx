import React from 'react';
import { MdChat, MdPlayCircleFilled, MdPhotoCamera, MdMusicNote } from 'react-icons/md';
import styles from '../../components/Dashboard/Dashboard.module.css';
import StatCard from '../../components/Dashboard/StatCard';
import SalesChart from '../../components/Dashboard/SalesChart';

const Dashboard = () => {
    return (
        <div className={styles.container}>
            <div className={styles.header}>
                <div>
                    <h1 className={styles.pageTitle}>Dashboard</h1>
                    <p className={styles.pageSubtitle}>Central Hub for Personal Customization</p>
                </div>
            </div>

            <div className={styles.grid}>
                <div className={styles.col}>
                    <StatCard
                        icon={<MdChat size={24} />}
                        title="Amazing mates"
                        value="9.3k"
                        color="info"
                    />
                </div>
                <div className={styles.col}>
                    <StatCard
                        icon={<MdPlayCircleFilled size={24} />}
                        title="Lessons Views"
                        value="24k"
                        color="danger"
                    />
                </div>
                <div className={styles.col}>
                    <StatCard
                        icon={<MdPhotoCamera size={24} />}
                        title="New subscribers"
                        value="608"
                        color="warning"
                    />
                </div>
                <div className={styles.col}>
                    <StatCard
                        icon={<MdMusicNote size={24} />}
                        title="Stream audience"
                        value="2.5k"
                        color="dark"
                    />
                </div>
            </div>

            <div className={styles.widgetsGrid}>
                <div className={styles.connectCard}>
                    <div className={styles.connectContent}>
                        <h2>Connect Today & Join the <span>Conceps Network</span></h2>
                        <p>Enhance your projects with premium themes and templates. Join the community today for top-quality designs.</p>
                        <button className="btn btn-primary">Get Started</button>
                    </div>
                    <div className={styles.connectImage}>
                        {/* Placeholder for illustration */}
                    </div>
                </div>

                <div className={styles.chartCard} style={{ gridColumn: 'span 2' }}>
                    <div className={styles.chartHeader}>
                        <h3>Earnings</h3>
                        <select className={styles.select}>
                            <option>12 months</option>
                            <option>30 days</option>
                        </select>
                    </div>
                    <div className={styles.chartSummary}>
                        <div className={styles.totalSales}>
                            <span>$34,233.00</span>
                            <span className={styles.badgeSuccess}>+24%</span>
                        </div>
                        <p className={styles.chartLabel}>June, 2024 Sales</p>
                    </div>
                    <SalesChart />
                </div>
            </div>

            <div className={styles.widgetsGrid}>
                <div className={styles.statCard} style={{ minHeight: '300px' }}>
                    <div className={styles.chartHeader}>
                        <h3>Highlights</h3>
                    </div>
                    <div className={styles.highlightContent}>
                        <h2 className={styles.highlightValue}>$295.7k <span className={styles.badgeSuccess}>+2.7%</span></h2>
                        <p className={styles.chartLabel}>All time sales</p>

                        <div className={styles.progressBars}>
                            {/* Simple progress bars */}
                            <div className={styles.barGroup}>
                                <div className={styles.barLabel}>
                                    <span className={styles.dot} style={{ background: 'var(--success)' }}></span> Metronic
                                </div>
                                <div className={styles.price}>$172k</div>
                            </div>
                            <div className={styles.barGroup}>
                                <div className={styles.barLabel}>
                                    <span className={styles.dot} style={{ background: 'var(--warning)' }}></span> Bundle
                                </div>
                                <div className={styles.price}>$85k</div>
                            </div>
                            <div className={styles.barGroup}>
                                <div className={styles.barLabel}>
                                    <span className={styles.dot} style={{ background: 'var(--primary)' }}></span> MetronicNest
                                </div>
                                <div className={styles.price}>$36k</div>
                            </div>
                        </div>
                    </div>
                </div>

                {/* Add more widgets as needed */}
            </div>

        </div>
    );
};

export default Dashboard;
