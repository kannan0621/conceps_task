import React, { useState } from 'react';
import { MdAdd, MdFilterList, MdSearch } from 'react-icons/md';
import Table from '../../components/DataDisplay/Table';
import styles from '../../components/DataDisplay/Table.module.css'; // Reusing table styles for utilities

const initialUsers = [
    { id: 1, name: 'Emma Smith', email: 'emma@example.com', role: 'Administrator', status: 'active', joined: '2023-01-15' },
    { id: 2, name: 'Ava Williams', email: 'ava@example.com', role: 'Editor', status: 'pending', joined: '2023-02-20' },
    { id: 3, name: 'James Brown', email: 'james@example.com', role: 'Viewer', status: 'inactive', joined: '2023-03-10' },
    { id: 4, name: 'Oliver Jones', email: 'oliver@example.com', role: 'Administrator', status: 'active', joined: '2023-04-05' },
    { id: 5, name: 'Lucas Garcia', email: 'lucas@example.com', role: 'Editor', status: 'active', joined: '2023-05-12' },
    { id: 6, name: 'Mia Miller', email: 'mia@example.com', role: 'Viewer', status: 'active', joined: '2023-06-18' },
    { id: 7, name: 'Amelia Davis', email: 'amelia@example.com', role: 'Editor', status: 'pending', joined: '2023-07-22' },
];

const UserList = () => {
    const [currentPage, setCurrentPage] = useState(1);
    const itemsPerPage = 5;

    // Pagination Logic
    const indexOfLastItem = currentPage * itemsPerPage;
    const indexOfFirstItem = indexOfLastItem - itemsPerPage;
    const currentItems = initialUsers.slice(indexOfFirstItem, indexOfLastItem);
    const totalPages = Math.ceil(initialUsers.length / itemsPerPage);

    const columns = [
        {
            header: 'User',
            accessor: 'name',
            render: (row) => (
                <div className={styles.avatarCell}>
                    <img
                        src={`https://ui-avatars.com/api/?name=${row.name}&background=random`}
                        alt={row.name}
                        className={styles.avatar}
                    />
                    <div className={styles.userInfo}>
                        <span className={styles.userName}>{row.name}</span>
                        <span className={styles.userEmail}>{row.email}</span>
                    </div>
                </div>
            )
        },
        { header: 'Role', accessor: 'role' },
        {
            header: 'Status',
            accessor: 'status',
            render: (row) => (
                <span className={`${styles.statusBadge} ${row.status === 'active' ? styles.statusActive :
                    row.status === 'pending' ? styles.statusPending :
                        styles.statusInactive
                    }`}>
                    {row.status}
                </span>
            )
        },
        { header: 'Joined', accessor: 'joined' },
        {
            header: 'Actions',
            accessor: 'actions',
            render: () => (
                <button className="btn btn-outline" style={{ padding: '4px 8px', fontSize: '0.75rem' }}>Edit</button>
            )
        }
    ];

    return (
        <div>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
                <div>
                    <h1 style={{ fontSize: '1.25rem', fontWeight: 700 }}>Users List</h1>
                    <p style={{ color: 'var(--text-muted)', fontSize: '0.875rem' }}>Manage your team members and their permissions.</p>
                </div>
                <div style={{ display: 'flex', gap: '10px' }}>
                    <button className="btn btn-outline"><MdFilterList size={20} /> Filter</button>
                    <button className="btn btn-primary"><MdAdd size={20} /> Add User</button>
                </div>
            </div>

            <Table
                columns={columns}
                data={currentItems}
                pagination={{
                    currentPage,
                    totalPages,
                    start: indexOfFirstItem + 1,
                    end: Math.min(indexOfLastItem, initialUsers.length),
                    total: initialUsers.length
                }}
                onPageChange={setCurrentPage}
            />
        </div>
    );
};

export default UserList;
