import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { MdStar, MdArrowBack, MdCheck } from 'react-icons/md';

// Mock data (in a real app this would come from an API/Store based on ID)
const productData = {
    id: 1,
    name: 'Modern Ergonomic Chair',
    category: 'Furniture',
    price: 299.99,
    rating: 4.8,
    reviews: 124,
    description: 'Experience ultimate comfort with our Modern Ergonomic Chair. Designed for long hours of work or gaming, this chair features adjustable lumbar support, breathable mesh material, and a sturdy aluminum base. The sleek design fits perfectly in any modern office or home setup.',
    features: [
        'Adjustable lumbar support',
        'Breathable mesh back',
        '360-degree swivel',
        'Height adjustable armrests',
        'Heavy-duty aluminum base'
    ],
    image: 'https://images.unsplash.com/photo-1592078615290-033ee584e267?auto=format&fit=crop&q=80&w=600'
};

const ProductDetail = () => {
    const { id } = useParams();
    // In real app: const product = fetchProduct(id);
    const product = productData;

    return (
        <div style={{ maxWidth: '1000px', margin: '0 auto' }}>
            <Link to="/products" style={{ display: 'inline-flex', alignItems: 'center', gap: '8px', marginBottom: '20px', color: 'var(--text-muted)' }}>
                <MdArrowBack /> Back to Products
            </Link>

            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: '40px', background: 'var(--white)', padding: '40px', borderRadius: 'var(--radius-lg)', border: '1px solid var(--gray-100)' }}>

                <div style={{ borderRadius: 'var(--radius-lg)', overflow: 'hidden', height: '400px' }}>
                    <img src={product.image} alt={product.name} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                </div>

                <div>
                    <span style={{ color: 'var(--primary)', fontWeight: 600, fontSize: '0.875rem', textTransform: 'uppercase' }}>
                        {product.category}
                    </span>
                    <h1 style={{ fontSize: '2rem', fontWeight: 800, margin: '8px 0' }}>{product.name}</h1>

                    <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '20px' }}>
                        <div style={{ display: 'flex', color: 'var(--warning)' }}>
                            {[...Array(5)].map((_, i) => <MdStar key={i} />)}
                        </div>
                        <span style={{ color: 'var(--text-muted)', fontSize: '0.875rem' }}>({product.reviews} reviews)</span>
                    </div>

                    <div style={{ fontSize: '2rem', fontWeight: 700, color: 'var(--text-main)', marginBottom: '20px' }}>
                        ${product.price}
                    </div>

                    <p style={{ color: 'var(--text-muted)', lineHeight: 1.6, marginBottom: '24px' }}>
                        {product.description}
                    </p>

                    <div style={{ marginBottom: '30px' }}>
                        <h3 style={{ fontSize: '1rem', fontWeight: 600, marginBottom: '12px' }}>Key Features</h3>
                        <ul style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                            {product.features.map((feature, i) => (
                                <li key={i} style={{ display: 'flex', alignItems: 'center', gap: '10px', color: 'var(--text-main)' }}>
                                    <MdCheck color="var(--success)" /> {feature}
                                </li>
                            ))}
                        </ul>
                    </div>

                    <div style={{ display: 'flex', gap: '16px' }}>
                        <button className="btn btn-primary" style={{ flex: 1, padding: '12px' }}>Add to Cart</button>
                        <button className="btn btn-outline" style={{ flex: 1, padding: '12px' }}>Buy Now</button>
                    </div>
                </div>

            </div>
        </div>
    );
};

export default ProductDetail;
