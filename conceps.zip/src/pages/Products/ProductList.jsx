import React from 'react';
import ProductCard from '../../components/Products/ProductCard';

const products = [
    {
        id: 1,
        name: 'Modern Ergonomic Chair',
        category: 'Furniture',
        price: 299.99,
        rating: 4.8,
        image: 'https://images.unsplash.com/photo-1592078615290-033ee584e267?auto=format&fit=crop&q=80&w=600',
        isNew: true
    },
    {
        id: 2,
        name: 'Minimalist Desk Lamp',
        category: 'Lighting',
        price: 89.50,
        rating: 4.5,
        image: 'https://images.unsplash.com/photo-1507473888900-52a11b8457d0?auto=format&fit=crop&q=80&w=600',
        isNew: false
    },
    {
        id: 3,
        name: 'Ceramic Plant Pot',
        category: 'Decor',
        price: 35.00,
        rating: 4.9,
        image: 'https://images.unsplash.com/photo-1485955900006-10f4d324d411?auto=format&fit=crop&q=80&w=600',
        isNew: true
    },
    {
        id: 4,
        name: 'Wireless Noise Cancelling Headphones',
        category: 'Electronics',
        price: 349.00,
        rating: 4.7,
        image: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&q=80&w=600',
        isNew: false
    },
    {
        id: 5,
        name: 'Abstract Wall Art',
        category: 'Art',
        price: 120.00,
        rating: 4.6,
        image: 'https://images.unsplash.com/photo-1513519245088-0e12902e35a6?auto=format&fit=crop&q=80&w=600',
        isNew: false
    },
    {
        id: 6,
        name: 'Smart Watch Series 5',
        category: 'Electronics',
        price: 399.00,
        rating: 4.8,
        image: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&q=80&w=600',
        isNew: true
    },
];

const ProductList = () => {
    return (
        <div>
            <div style={{ marginBottom: '20px' }}>
                <h1 style={{ fontSize: '1.5rem', fontWeight: 700, marginBottom: '8px' }}>Products</h1>
                <p style={{ color: 'var(--text-muted)' }}>Explore our latest collection of premium items.</p>
            </div>

            <div style={{
                display: 'grid',
                gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))',
                gap: '24px'
            }}>
                {products.map(product => (
                    <ProductCard key={product.id} product={product} />
                ))}
            </div>
        </div>
    );
};

export default ProductList;
