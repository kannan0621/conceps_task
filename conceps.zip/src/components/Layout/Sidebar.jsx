import React from 'react';
import { NavLink } from 'react-router-dom';
import {
    MdDashboard,
    MdPerson,
    MdGroup,
    MdSettings,
    MdShoppingCart,
    MdEmail,
    MdLock,
    MdList,
    MdInput,
    MdClose
} from 'react-icons/md';
import styles from './Sidebar.module.css';

const Sidebar = ({ isOpen, onClose }) => {
    return (
        <aside className={`${styles.sidebar} ${isOpen ? styles.open : ''}`}>
            <div className={styles.logoRow}>
                <div className={styles.logo}>
                    <h1>CONCEPS</h1>
                </div>
                <button className={styles.closeBtn} onClick={onClose}>
                    <MdClose size={24} />
                </button>
            </div>

            <nav className={styles.nav}>
                <div className={styles.section}>
                    <h3>Core</h3>
                    <NavLink
                        to="/"
                        className={({ isActive }) => `${styles.link} ${isActive ? styles.active : ''}`}
                        onClick={onClose}
                    >
                        <MdDashboard size={20} />
                        <span>Dashboard</span>
                    </NavLink>

                    <NavLink
                        to="/forms/registration"
                        className={({ isActive }) => `${styles.link} ${isActive ? styles.active : ''}`}
                        onClick={onClose}
                    >
                        <MdInput size={20} />
                        <span>Registration</span>
                    </NavLink>

                    <NavLink
                        to="/lists/users"
                        className={({ isActive }) => `${styles.link} ${isActive ? styles.active : ''}`}
                        onClick={onClose}
                    >
                        <MdList size={20} />
                        <span>User List</span>
                    </NavLink>

                    <NavLink
                        to="/products"
                        className={({ isActive }) => `${styles.link} ${isActive ? styles.active : ''}`}
                        onClick={onClose}
                    >
                        <MdShoppingCart size={20} />
                        <span>Products</span>
                    </NavLink>
                </div>

                <div className={styles.section}>
                    <h3>Auth Pages</h3>
                    <NavLink
                        to="/auth/signin"
                        className={({ isActive }) => `${styles.link} ${isActive ? styles.active : ''}`}
                        onClick={onClose}
                    >
                        <MdLock size={20} />
                        <span>Sign In</span>
                    </NavLink>
                </div>
            </nav>
        </aside>
    );
};

export default Sidebar;
