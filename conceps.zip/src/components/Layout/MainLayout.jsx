import React, { useState, useEffect } from 'react';
import { Outlet } from 'react-router-dom';
import Sidebar from './Sidebar';
import styles from './MainLayout.module.css';
import { MdSearch, MdNotifications, MdChatBubbleOutline, MdApps, MdLightMode, MdDarkMode } from 'react-icons/md';

const MainLayout = () => {
    const [darkMode, setDarkMode] = useState(() => {
        return localStorage.getItem('theme') === 'dark';
    });

    const [isSidebarOpen, setIsSidebarOpen] = useState(false);

    useEffect(() => {
        if (darkMode) {
            document.documentElement.setAttribute('data-theme', 'dark');
            localStorage.setItem('theme', 'dark');
        } else {
            document.documentElement.removeAttribute('data-theme');
            localStorage.setItem('theme', 'light');
        }
    }, [darkMode]);

    return (
        <div className={styles.layout}>
            {/* Overlay for mobile */}
            {isSidebarOpen && (
                <div
                    className={styles.overlay}
                    onClick={() => setIsSidebarOpen(false)}
                />
            )}

            <Sidebar isOpen={isSidebarOpen} onClose={() => setIsSidebarOpen(false)} />

            <main className={`${styles.main} ${isSidebarOpen ? styles.mainWithSidebar : ''}`}>
                <header className={styles.header}>
                    <div className={styles.leftHeader}>
                        <button
                            className={styles.menuBtn}
                            onClick={() => setIsSidebarOpen(!isSidebarOpen)}
                        >
                            <MdApps size={24} />
                        </button>
                        <div className={styles.breadcrumb}>
                            <span>Dashboards</span> &gt; <span className={styles.activePage}>Default</span>
                        </div>
                    </div>

                    <div className={styles.actions}>
                        <div className={styles.search}>
                            <MdSearch size={22} className={styles.searchIcon} />
                        </div>

                        <button className={styles.iconBtn} onClick={() => setDarkMode(!darkMode)} title="Toggle Theme">
                            {darkMode ? <MdLightMode size={20} /> : <MdDarkMode size={20} />}
                        </button>

                        <button className={styles.iconBtn}>
                            <MdNotifications size={20} />
                        </button>

                        <button className={styles.iconBtn}>
                            <MdChatBubbleOutline size={20} />
                        </button>

                        <div className={styles.userProfile}>
                            <img src="https://ui-avatars.com/api/?name=User&background=random" alt="User" />
                        </div>
                    </div>
                </header>

                <div className={styles.content}>
                    <Outlet />
                </div>
            </main>
        </div>
    );
};

export default MainLayout;
