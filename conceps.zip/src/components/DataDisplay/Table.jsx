import React from 'react';
import { MdChevronLeft, MdChevronRight } from 'react-icons/md';
import styles from './Table.module.css';

const Table = ({ columns, data, pagination, onPageChange }) => {
    return (
        <div className={styles.tableContainer}>
            <div className={styles.tableWrapper}>
                <table className={styles.table}>
                    <thead>
                        <tr>
                            {columns.map((col, index) => (
                                <th key={index} style={{ width: col.width }}>{col.header}</th>
                            ))}
                        </tr>
                    </thead>
                    <tbody>
                        {data.map((row, rowIndex) => (
                            <tr key={rowIndex}>
                                {columns.map((col, colIndex) => (
                                    <td key={colIndex}>
                                        {col.render ? col.render(row) : row[col.accessor]}
                                    </td>
                                ))}
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>

            {pagination && (
                <div className={styles.pagination}>
                    <span className={styles.pageInfo}>
                        Showing {pagination.start} to {pagination.end} of {pagination.total} entries
                    </span>
                    <div className={styles.pageControls}>
                        <button
                            className={styles.pageBtn}
                            disabled={pagination.currentPage === 1}
                            onClick={() => onPageChange(pagination.currentPage - 1)}
                        >
                            <MdChevronLeft size={20} />
                        </button>
                        {Array.from({ length: Math.min(5, pagination.totalPages) }, (_, i) => {
                            // Simple pagination logic for demo
                            const pageNum = i + 1;
                            return (
                                <button
                                    key={pageNum}
                                    className={`${styles.pageBtn} ${pagination.currentPage === pageNum ? styles.activePage : ''}`}
                                    onClick={() => onPageChange(pageNum)}
                                >
                                    {pageNum}
                                </button>
                            )
                        })}
                        <button
                            className={styles.pageBtn}
                            disabled={pagination.currentPage === pagination.totalPages}
                            onClick={() => onPageChange(pagination.currentPage + 1)}
                        >
                            <MdChevronRight size={20} />
                        </button>
                    </div>
                </div>
            )}
        </div>
    );
};

export default Table;
