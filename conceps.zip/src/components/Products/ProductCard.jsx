import React from 'react';
import { MdStar, MdAddShoppingCart } from 'react-icons/md';
import { Link } from 'react-router-dom';
import styles from './ProductCard.module.css';

const ProductCard = ({ product }) => {
    return (
        <div className={styles.card}>
            <Link to={`/products/${product.id}`} className={styles.imageContainer}>
                <img src={product.image} alt={product.name} className={styles.image} />
                {product.isNew && <span className={styles.badge}>New</span>}
            </Link>

            <div className={styles.content}>
                <span className={styles.category}>{product.category}</span>
                <h3 className={styles.title}>
                    <Link to={`/products/${product.id}`}>{product.name}</Link>
                </h3>

                <div className={styles.footer}>
                    <div className={styles.price}>${product.price}</div>
                    <div className={styles.rating}>
                        <MdStar /> <span>{product.rating}</span>
                    </div>
                </div>

                <button className="btn btn-primary" style={{ marginTop: '1rem', width: '100%' }}>
                    <MdAddShoppingCart size={18} style={{ marginRight: '8px' }} /> Add to Cart
                </button>
            </div>
        </div>
    );
};

export default ProductCard;
