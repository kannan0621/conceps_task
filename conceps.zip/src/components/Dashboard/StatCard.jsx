import React from 'react';
import styles from './Dashboard.module.css';

const StatCard = ({ icon, title, value, subtext, color, trend }) => {
    return (
        <div className={styles.statCard}>
            <div className={styles.statHeader}>
                <div className={styles.iconBox} style={{ backgroundColor: `var(--${color})`, color: '#fff' }}>
                    {icon}
                </div>
            </div>
            <div className={styles.statBody}>
                <h2 className={styles.statValue}>{value}</h2>
                <p className={styles.statTitle}>{title}</p>
                {subtext && <p className={styles.statSub}>{subtext}</p>}
            </div>
        </div >
    );
};

export default StatCard;
