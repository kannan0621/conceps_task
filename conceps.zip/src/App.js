import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import MainLayout from './components/Layout/MainLayout';
import Dashboard from './pages/Dashboard/Dashboard';
import SignIn from './pages/Auth/SignIn';
import SignUp from './pages/Auth/SignUp';
import VerifyOTP from './pages/Auth/VerifyOTP';
import UserList from './pages/Lists/UserList';
import ProductList from './pages/Products/ProductList';
import ProductDetail from './pages/Products/ProductDetail';
import RegistrationForm from './pages/Forms/RegistrationForm';
import './index.css';

function App() {
  return (
    <Router>
      <Routes>
        {/* Auth Routes - Without Layout */}
        <Route path="/auth/signin" element={<SignIn />} />
        <Route path="/auth/signup" element={<SignUp />} />
        <Route path="/auth/verify-otp" element={<VerifyOTP />} />

        {/* Main App Routes - With Layout */}
        <Route path="/" element={<MainLayout />}>
          <Route index element={<Dashboard />} />
          <Route path="lists/users" element={<UserList />} />
          <Route path="products" element={<ProductList />} />
          <Route path="products/:id" element={<ProductDetail />} />
          <Route path="forms/registration" element={<RegistrationForm />} />

          {/* Placeholders for links in sidebar that don't have pages yet */}
          <Route path="profile" element={<h2>Public Profile</h2>} />
          <Route path="account" element={<h2>My Account</h2>} />
        </Route>

        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </Router>
  );
}

export default App;
